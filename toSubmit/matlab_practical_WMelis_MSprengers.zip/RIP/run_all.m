run('part1_lin_model.m');
run('part2_designController.m');
run('part3_designController.m');
run('part4_plots.m');
run('part5_plots.m');
clc;clear all;
close all;